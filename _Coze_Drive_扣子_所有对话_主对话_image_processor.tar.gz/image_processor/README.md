# 图片批量抠图处理系统

> 基于 BiRefNet / RMBG-2.0 的智能抠图系统，支持批量上传、文件夹监控、标签管理、自定义命名、Docker 部署。

---

## 功能特性

| 功能 | 说明 |
|------|------|
| 📤 **批量上传** | 拖拽/选择多张图片，支持 PNG/JPG/BMP/WebP/TIFF |
| 🤖 **智能抠图** | BiRefNet / RMBG-2.0 模型，GPU/CPU 自适应 |
| 📁 **文件夹监控** | watchdog 自动扫描新图片并处理 |
| 🏷️ **标签管理** | 单张/批量打标签，支持搜索过滤 |
| 📝 **备注系统** | 每张图可添加独立备注 |
| ✏️ **批量命名** | 自定义模板：前缀+序号/时间戳/原文件名 |
| 💾 **自动输出** | 处理后图片自动保存到指定目录 |
| 📊 **处理记录** | SQLite 数据库记录完整处理历史 |
| 🔌 **REST API** | 完整 API 接口，支持外部系统集成 |
| 🐳 **Docker 部署** | 一键 Docker Compose 部署到服务器 |

---

## 项目结构

```
image_processor/
├── app/
│   ├── __init__.py         # 包初始化
│   ├── main.py             # FastAPI 主应用入口
│   ├── config.py           # 配置文件（环境变量覆盖）
│   ├── database.py         # SQLite 数据库模型 + CRUD
│   ├── processor.py        # BiRefNet/RMBG 抠图处理模块
│   ├── watcher.py          # watchdog 文件夹监控模块
│   ├── api.py              # REST API 路由
│   └── utils.py            # 工具函数（命名、标签解析等）
├── static/
│   └── index.html          # 前端页面（Bootstrap + 原生JS）
├── data/
│   ├── uploads/            # 上传文件临时目录
│   ├── outputs/            # 处理后输出目录
│   ├── processed/          # 已处理原图归档
│   └── image_processor.db  # SQLite 数据库文件
├── logs/
│   └── app.log             # 应用日志
├── Dockerfile              # GPU 版 Dockerfile
├── Dockerfile.cpu          # CPU 版 Dockerfile
├── docker-compose.yml      # Docker Compose 编排
├── requirements.txt        # Python 依赖
├── .dockerignore
└── README.md               # 部署文档
```

---

## 快速开始

### 方式一：Docker 部署（推荐）

#### 前置要求
- Docker >= 20.10
- Docker Compose >= 2.0
- (GPU 版) NVIDIA Driver + NVIDIA Container Toolkit

#### GPU 部署

```bash
# 1. 克隆或上传项目到服务器
cd image_processor

# 2. 启动服务
docker compose up -d

# 3. 查看日志
docker compose logs -f app
```

#### CPU 部署

```bash
# 编辑 docker-compose.yml，注释掉 GPU 版 app 段，取消 app-cpu 段注释
# 然后：
docker compose up -d --build
```

#### 访问
- **前端页面**: http://47.84.3.161:8000
- **API 文档**: http://47.84.3.161:8000/docs
- **健康检查**: http://47.84.3.161:8000/api/health

---

### 方式二：本地开发运行

```bash
# 1. 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. 安装依赖
pip install -r requirements.txt

# 3. 启动服务
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

# 访问 http://localhost:8000
```

---

## 配置说明

所有配置通过环境变量覆盖，在 `docker-compose.yml` 的 `environment` 段修改：

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `APP_PORT` | 8000 | 服务端口 |
| `APP_DEBUG` | false | 调试模式 |
| `MODEL_TYPE` | birefnet | 模型类型：`birefnet` 或 `rmbg2` |
| `BIREFNET_MODEL` | ZHengyj77/BiRefNet | BiRefNet HuggingFace 模型名 |
| `RMBG2_MODEL` | briaai/RMBG-2.0 | RMBG-2.0 模型名 |
| `MAX_IMAGE_SIZE` | 4096 | 图片最大边长（px），超过自动缩放 |
| `MAX_UPLOAD_SIZE` | 52428800 | 单文件最大上传大小（字节） |
| `MAX_WORKERS` | 4 | 并发处理线程数 |
| `WATCH_DIR` | (空) | 文件夹监控目录，留空不启用 |
| `WATCH_RECURSIVE` | true | 是否递归监控子目录 |
| `WATCH_SETTLE_TIME` | 2.0 | 文件写入等待时间（秒） |
| `NAME_TEMPLATE` | {prefix}_{index:04d} | 默认命名模板 |
| `DEFAULT_PREFIX` | cutout | 默认命名前缀 |
| `CORS_ORIGINS` | * | CORS 允许的来源 |

---

## 命名模板说明

支持以下变量：

| 变量 | 说明 | 示例 |
|------|------|------|
| `{prefix}` | 前缀字符串 | `cutout` |
| `{index}` | 序号（支持格式化） | `1` |
| `{timestamp}` | 时间戳 | `20240101120000` |
| `{original_name}` | 原始文件名（不含扩展名） | `photo001` |
| `{date}` | 日期 | `20240101` |
| `{time}` | 时间 | `120000` |

**常用模板示例：**

```
{prefix}_{index:04d}           → cutout_0001
{original_name}_nobg           → photo001_nobg
{date}_{time}_{index:03d}      → 20240101_120000_001
{prefix}_{original_name}       → cutout_photo001
```

---

## REST API 接口

完整 Swagger 文档：`http://host:8000/docs`

### 核心接口

| 方法 | 路径 | 说明 |
|------|------|------|
| `POST` | `/api/upload` | 批量上传并处理 |
| `POST` | `/api/upload/async` | 异步上传（仅保存，不立即处理） |
| `POST` | `/api/process/{batch_id}` | 手动触发批次处理 |
| `GET` | `/api/records` | 查询记录列表（支持分页/过滤） |
| `GET` | `/api/records/{id}` | 查询单条记录 |
| `DELETE` | `/api/records/{id}` | 删除记录 |
| `PUT` | `/api/records/{id}/note` | 更新备注 |
| `PUT` | `/api/records/batch/tags` | 批量追加标签 |
| `GET` | `/api/download/{id}` | 下载处理后的图片 |
| `GET` | `/api/download/{id}/original` | 下载原始图片 |
| `GET` | `/api/stats` | 统计信息 |
| `GET` | `/api/watcher/status` | 监控器状态 |
| `POST` | `/api/watcher/start` | 启动文件夹监控 |
| `POST` | `/api/watcher/stop` | 停止文件夹监控 |
| `GET` | `/api/config` | 系统配置 |
| `GET` | `/api/health` | 健康检查 |

### 接口示例

#### 上传处理

```bash
curl -X POST http://47.84.3.161:8000/api/upload \
  -F "files=@photo1.jpg" \
  -F "files=@photo2.png" \
  -F "tags=产品图,白底" \
  -F "note=第一批产品图" \
  -F "naming_template={prefix}_{index:04d}"
```

#### 查询记录

```bash
curl "http://47.84.3.161:8000/api/records?skip=0&limit=20&status=success&tag=产品图"
```

#### 批量打标签

```bash
curl -X PUT http://47.84.3.161:8000/api/records/batch/tags \
  -F "record_ids=1,2,3,4,5" \
  -F "tags=已审核,优先处理"
```

---

## 文件夹监控

### 启用方式

1. 设置环境变量 `WATCH_DIR` 为要监控的目录
2. 在 docker-compose.yml 中挂载该目录
3. 启动服务后通过 API 或前端页面启动监控

```yaml
# docker-compose.yml 中添加
volumes:
  - /data/images/incoming:/app/watch_images
environment:
  - WATCH_DIR=/app/watch_images
```

放入该目录的图片将自动检测并处理。

---

## 模型说明

| 模型 | 参数量 | 精度 | 速度 | 适用场景 |
|------|--------|------|------|----------|
| **BiRefNet** | ~200M | ★★★★★ | ★★★ | 高质量抠图，复杂边缘 |
| **RMBG-2.0** | ~40M | ★★★★ | ★★★★★ | 快速抠图，轻量部署 |

首次启动时自动从 HuggingFace 下载模型（可能需要几分钟），后续使用本地缓存。

---

## 部署到 47.84.3.161:8000

```bash
# 1. SSH 到服务器
ssh root@47.84.3.161

# 2. 确保安装 Docker
curl -fsSL https://get.docker.com | sh
# 安装 NVIDIA Container Toolkit（GPU 版）
# distribution=$(. /etc/os-release;echo $ID$VERSION_ID)
# curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
# ...

# 3. 上传项目代码
scp -r image_processor/ root@47.84.3.161:/opt/image_processor

# 4. 启动
cd /opt/image_processor
docker compose up -d

# 5. 查看日志
docker compose logs -f

# 6. 验证
curl http://localhost:8000/api/health
```

---

## 日志

- 应用日志：`logs/app.log`
- Docker 日志：`docker compose logs -f app`
- 日志格式：`时间 [级别] 模块: 消息`

---

## 技术栈

| 组件 | 技术 |
|------|------|
| 后端框架 | FastAPI |
| 抠图引擎 | BiRefNet / RMBG-2.0 (transformers) |
| 深度学习 | PyTorch |
| 数据库 | SQLite + SQLAlchemy |
| 文件监控 | watchdog |
| 前端 | HTML + Bootstrap 5 + 原生 JS |
| 部署 | Docker + Docker Compose |

---

## License

MIT
