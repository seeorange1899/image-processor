"""
图片批量抠图处理系统 - 工具函数
命名规则、文件处理等通用工具
"""
import json
import re
import uuid
import logging
from datetime import datetime
from pathlib import Path
from typing import List

from . import config

logger = logging.getLogger(__name__)


def generate_batch_id() -> str:
    """生成唯一批次ID"""
    return f"batch_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"


def generate_output_name(template: str, index: int, original_name: str,
                         prefix: str = None, timestamp: str = None) -> str:
    """
    根据命名模板生成输出文件名

    模板变量:
    - {prefix}: 前缀字符串
    - {index}: 序号
    - {timestamp}: 时间戳
    - {original_name}: 原始文件名（不含扩展名）
    - {date}: 日期 YYYYMMDD
    - {time}: 时间 HHMMSS

    示例:
    - "{prefix}_{index:04d}"  -> "cutout_0001"
    - "{original_name}_cutout" -> "photo_cutout"
    - "{date}_{time}_{index:03d}" -> "20240101_120000_001"
    """
    now = datetime.utcnow()
    name_without_ext = Path(original_name).stem

    # 构建变量字典
    variables = {
        "prefix": prefix or config.DEFAULT_PREFIX,
        "index": index,
        "timestamp": timestamp or now.strftime("%Y%m%d%H%M%S"),
        "original_name": name_without_ext,
        "date": now.strftime("%Y%m%d"),
        "time": now.strftime("%H%M%S"),
    }

    try:
        # 安全地格式化模板
        result = template.format(**variables)
    except (KeyError, ValueError, IndexError) as e:
        logger.warning(f"命名模板解析失败: {template}, 使用默认命名. 错误: {e}")
        result = f"{variables['prefix']}_{index:04d}"

    return result


def validate_image_file(file_path: str) -> bool:
    """验证文件是否为支持的图片格式"""
    path = Path(file_path)
    if not path.exists():
        return False
    return path.suffix.lower() in config.ALLOWED_EXTENSIONS


def get_file_size_kb(file_path: str) -> float:
    """获取文件大小（KB）"""
    try:
        return round(Path(file_path).stat().st_size / 1024, 2)
    except Exception:
        return 0.0


def parse_tags(tags_input) -> List[str]:
    """
    解析标签输入，支持多种格式:
    - JSON 数组字符串: '["tag1", "tag2"]'
    - 逗号分隔字符串: "tag1,tag2,tag3"
    - 列表: ["tag1", "tag2"]
    """
    if isinstance(tags_input, list):
        return [str(t).strip() for t in tags_input if str(t).strip()]

    if isinstance(tags_input, str):
        tags_input = tags_input.strip()
        if not tags_input:
            return []

        # 尝试 JSON 解析
        if tags_input.startswith("["):
            try:
                parsed = json.loads(tags_input)
                if isinstance(parsed, list):
                    return [str(t).strip() for t in parsed if str(t).strip()]
            except json.JSONDecodeError:
                pass

        # 逗号分隔
        return [t.strip() for t in tags_input.split(",") if t.strip()]

    return []


def safe_filename(name: str) -> str:
    """清理文件名，移除不安全字符"""
    # 只保留中文、英文、数字、下划线、短横线、点
    name = re.sub(r'[^\w\u4e00-\u9fff\-.]', '_', name)
    # 限制长度
    if len(name) > 200:
        stem = Path(name).stem[:190]
        ext = Path(name).suffix
        name = stem + ext
    return name
