"""
图片批量抠图处理系统 - 配置文件
"""
import os
from pathlib import Path

# ============================================================
# 基础路径配置
# ============================================================
BASE_DIR = Path(__file__).resolve().parent.parent  # 项目根目录
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"       # 上传文件临时目录
OUTPUT_DIR = DATA_DIR / "outputs"       # 处理后输出目录
PROCESSED_DIR = DATA_DIR / "processed"  # 已处理原图归档
LOG_DIR = BASE_DIR / "logs"
DB_PATH = DATA_DIR / "image_processor.db"

# 确保目录存在
for d in [UPLOAD_DIR, OUTPUT_DIR, PROCESSED_DIR, LOG_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ============================================================
# 服务配置
# ============================================================
HOST = os.getenv("APP_HOST", "0.0.0.0")
PORT = int(os.getenv("APP_PORT", "8000"))
DEBUG = os.getenv("APP_DEBUG", "false").lower() == "true"
SECRET_KEY = os.getenv("SECRET_KEY", "image-processor-secret-key-2024")

# ============================================================
# 模型配置
# ============================================================
# 支持的模型: "birefnet" | "rmbg2"
MODEL_TYPE = os.getenv("MODEL_TYPE", "birefnet")
# BiRefNet 模型名（HuggingFace）
BIREFNET_MODEL = os.getenv("BIREFNET_MODEL", "ZHengyj77/BiRefNet")
# RMBG-2.0 模型名
RMBG2_MODEL = os.getenv("RMBG2_MODEL", "briaai/RMBG-2.0")
# 模型缓存目录
MODEL_CACHE_DIR = os.getenv("MODEL_CACHE_DIR", str(BASE_DIR / "models_cache"))

# ============================================================
# 处理配置
# ============================================================
# 单张图片最大尺寸（像素），超过会自动缩放
MAX_IMAGE_SIZE = int(os.getenv("MAX_IMAGE_SIZE", "4096"))
# 支持的图片格式
ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tiff", ".tif"}
# 最大上传文件大小（字节），默认 50MB
MAX_UPLOAD_SIZE = int(os.getenv("MAX_UPLOAD_SIZE", str(50 * 1024 * 1024)))
# 并发处理线程数
MAX_WORKERS = int(os.getenv("MAX_WORKERS", "4"))
# 批量处理每批数量
BATCH_SIZE = int(os.getenv("BATCH_SIZE", "10"))

# ============================================================
# 文件夹监控配置
# ============================================================
WATCH_DIR = os.getenv("WATCH_DIR", "")  # 为空则不启用监控
WATCH_RECURSIVE = os.getenv("WATCH_RECURSIVE", "true").lower() == "true"
# 文件创建后等待时间（秒），确保文件写入完成
WATCH_SETTLE_TIME = float(os.getenv("WATCH_SETTLE_TIME", "2.0"))

# ============================================================
# 命名规则配置
# ============================================================
# 默认命名模板: {prefix}_{index:04d}
# 可用变量: {prefix}, {index}, {timestamp}, {original_name}, {date}, {time}
DEFAULT_NAME_TEMPLATE = os.getenv("NAME_TEMPLATE", "{prefix}_{index:04d}")
DEFAULT_PREFIX = os.getenv("DEFAULT_PREFIX", "cutout")

# ============================================================
# CORS 配置
# ============================================================
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")
