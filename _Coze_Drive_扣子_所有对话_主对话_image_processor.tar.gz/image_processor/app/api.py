"""
图片批量抠图处理系统 - REST API 接口
提供图片上传、处理、查询、标签管理等完整API
"""
import json
import logging
import shutil
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional, List

from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException, Query, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy.orm import Session

from . import config
from .database import SessionLocal, ImageCRUD, ImageRecord, init_db
from .processor import get_processor
from .utils import (
    generate_batch_id, generate_output_name,
    validate_image_file, get_file_size_kb, parse_tags, safe_filename
)

logger = logging.getLogger(__name__)

router = APIRouter()

# 处理任务队列（简易版，生产环境建议用 Celery）
_processing_lock = threading.Lock()
_processing_queue = []


# ============================================================
# 辅助函数
# ============================================================
def get_db_session():
    """获取数据库会话"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _process_single_image(file_path: str, batch_id: str = None,
                           naming_template: str = None, tags: str = None,
                           note: str = None):
    """
    处理单张图片（内部函数，可在后台线程执行）
    :param file_path: 输入文件路径
    :param batch_id: 批次ID
    :param naming_template: 命名模板
    :param tags: 标签（JSON字符串）
    :param note: 备注
    """
    db = SessionLocal()
    try:
        file_path = Path(file_path)
        original_name = file_path.name

        # 查找或创建记录
        record = db.query(ImageRecord).filter(
            ImageRecord.original_path == str(file_path)
        ).first()

        if not record:
            # 创建新记录
            record = ImageCRUD.create(
                db,
                original_name=original_name,
                original_path=str(file_path),
                file_size=get_file_size_kb(str(file_path)),
                status="pending",
                batch_id=batch_id or generate_batch_id(),
                naming_template=naming_template or config.DEFAULT_NAME_TEMPLATE,
                tags=tags or "[]",
                note=note or "",
                model_type=config.MODEL_TYPE,
            )
            logger.info(f"创建处理记录: {original_name} (ID: {record.id})")

        # 更新状态为处理中
        ImageCRUD.update(db, record.id,
                         status="processing",
                         process_start_time=datetime.utcnow())

        # 生成输出文件名
        template = record.naming_template or config.DEFAULT_NAME_TEMPLATE
        output_name = generate_output_name(
            template=template,
            index=record.id,
            original_name=original_name,
        )
        output_name = safe_filename(output_name + ".png")
        output_path = str(config.OUTPUT_DIR / output_name)

        # 执行抠图
        processor = get_processor()
        result = processor.process_file(str(file_path), output_path)

        if result["success"]:
            # 将原图归档到 processed 目录
            archive_path = str(config.PROCESSED_DIR / original_name)
            try:
                shutil.move(str(file_path), archive_path)
            except Exception:
                pass  # 归档失败不影响主流程

            ImageCRUD.update(
                db, record.id,
                status="success",
                output_name=output_name,
                output_path=output_path,
                process_end_time=datetime.utcnow(),
                width=result["width"],
                height=result["height"],
            )
            logger.info(f"处理成功: {original_name} -> {output_name}")
        else:
            ImageCRUD.update(
                db, record.id,
                status="failed",
                error_message=result["error"],
                process_end_time=datetime.utcnow(),
            )
            logger.error(f"处理失败: {original_name} - {result['error']}")

    except Exception as e:
        logger.error(f"处理图片异常: {file_path} - {e}")
        # 尝试更新记录状态
        try:
            record = db.query(ImageRecord).filter(
                ImageRecord.original_path == str(file_path)
            ).first()
            if record:
                ImageCRUD.update(db, record.id,
                                 status="failed",
                                 error_message=str(e),
                                 process_end_time=datetime.utcnow())
        except Exception:
            pass
    finally:
        db.close()


def _process_batch_internal(file_paths: List[str], batch_id: str,
                             naming_template: str, tags: str, note: str):
    """批量处理图片（后台线程）"""
    for i, file_path in enumerate(file_paths, 1):
        logger.info(f"批量处理 [{i}/{len(file_paths)}]: {file_path}")
        _process_single_image(file_path, batch_id, naming_template, tags, note)


def _watcher_callback(file_path: str):
    """文件夹监控回调函数"""
    logger.info(f"监控器检测到新图片: {file_path}")
    thread = threading.Thread(
        target=_process_single_image,
        args=(file_path,),
        daemon=True,
    )
    thread.start()


# ============================================================
# API 路由
# ============================================================

@router.get("/api/health")
async def health_check():
    """健康检查"""
    return {
        "status": "ok",
        "timestamp": datetime.utcnow().isoformat(),
        "model_type": config.MODEL_TYPE,
        "watch_dir": config.WATCH_DIR or "未启用",
    }


@router.get("/api/stats")
async def get_stats(db: Session = Depends(get_db_session)):
    """获取统计信息"""
    return ImageCRUD.get_stats(db)


# ----- 上传与处理 -----

@router.post("/api/upload")
async def upload_images(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(..., description="上传的图片文件"),
    tags: str = Form(default="[]", description="标签（JSON数组或逗号分隔）"),
    note: str = Form(default="", description="备注"),
    naming_template: str = Form(default=None, description="命名模板"),
    batch_id: str = Form(default=None, description="批次ID（为空自动生成）"),
    db: Session = Depends(get_db_session),
):
    """
    批量上传图片并加入处理队列
    - files: 图片文件列表
    - tags: 标签（JSON数组或逗号分隔字符串）
    - note: 备注
    - naming_template: 命名模板，如 {prefix}_{index:04d}
    - batch_id: 批次ID
    """
    if not files:
        raise HTTPException(status_code=400, detail="未选择文件")

    # 生成批次ID
    if not batch_id:
        batch_id = generate_batch_id()

    # 验证标签
    tag_list = parse_tags(tags)
    tags_json = json.dumps(tag_list, ensure_ascii=False)

    # 保存上传文件
    saved_paths = []
    errors = []

    for file in files:
        try:
            # 验证文件扩展名
            suffix = Path(file.filename).suffix.lower()
            if suffix not in config.ALLOWED_EXTENSIONS:
                errors.append(f"不支持的格式: {file.filename}")
                continue

            # 生成安全文件名
            safe_name = safe_filename(file.filename)
            save_path = config.UPLOAD_DIR / f"{batch_id}_{safe_name}"

            # 写入文件
            with open(save_path, "wb") as f:
                content = await file.read()
                if len(content) > config.MAX_UPLOAD_SIZE:
                    errors.append(f"文件过大: {file.filename} (>{config.MAX_UPLOAD_SIZE // 1024 // 1024}MB)")
                    continue
                f.write(content)

            saved_paths.append(str(save_path))

        except Exception as e:
            errors.append(f"上传失败: {file.filename} - {str(e)}")

    if not saved_paths:
        raise HTTPException(status_code=400, detail=f"无有效文件上传。错误: {errors}")

    # 后台批量处理
    background_tasks.add_task(
        _process_batch_internal,
        saved_paths, batch_id,
        naming_template or config.DEFAULT_NAME_TEMPLATE,
        tags_json, note,
    )

    return {
        "message": f"已接收 {len(saved_paths)} 个文件，正在后台处理",
        "batch_id": batch_id,
        "file_count": len(saved_paths),
        "errors": errors,
    }


@router.post("/api/upload/async")
async def upload_async(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    tags: str = Form(default="[]"),
    note: str = Form(default=""),
    naming_template: str = Form(default=None),
    db: Session = Depends(get_db_session),
):
    """异步上传：只保存文件，不立即处理（手动触发处理）"""
    if not files:
        raise HTTPException(status_code=400, detail="未选择文件")

    batch_id = generate_batch_id()
    tag_list = parse_tags(tags)
    tags_json = json.dumps(tag_list, ensure_ascii=False)

    records_created = []
    errors = []

    for file in files:
        try:
            suffix = Path(file.filename).suffix.lower()
            if suffix not in config.ALLOWED_EXTENSIONS:
                errors.append(f"不支持的格式: {file.filename}")
                continue

            safe_name = safe_filename(file.filename)
            save_path = config.UPLOAD_DIR / f"{batch_id}_{safe_name}"

            with open(save_path, "wb") as f:
                content = await file.read()
                f.write(content)

            # 创建记录
            record = ImageCRUD.create(
                db,
                original_name=file.filename,
                original_path=str(save_path),
                file_size=get_file_size_kb(str(save_path)),
                status="pending",
                batch_id=batch_id,
                naming_template=naming_template or config.DEFAULT_NAME_TEMPLATE,
                tags=tags_json,
                note=note,
            )
            records_created.append(record.id)

        except Exception as e:
            errors.append(f"上传失败: {file.filename} - {str(e)}")

    return {
        "message": f"已保存 {len(records_created)} 个文件，等待处理",
        "batch_id": batch_id,
        "record_ids": records_created,
        "errors": errors,
    }


@router.post("/api/process/{batch_id}")
async def process_batch(
    batch_id: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db_session),
):
    """手动触发批次处理"""
    records = db.query(ImageRecord).filter(
        ImageRecord.batch_id == batch_id,
        ImageRecord.status == "pending"
    ).all()

    if not records:
        raise HTTPException(status_code=404, detail="未找到待处理记录")

    file_paths = [r.original_path for r in records if r.original_path]

    background_tasks.add_task(
        _process_batch_internal,
        file_paths, batch_id,
        records[0].naming_template or config.DEFAULT_NAME_TEMPLATE,
        records[0].tags or "[]",
        records[0].note or "",
    )

    return {"message": f"已开始处理 {len(file_paths)} 张图片", "batch_id": batch_id}


# ----- 记录查询 -----

@router.get("/api/records")
async def list_records(
    skip: int = Query(0, ge=0, description="跳过条数"),
    limit: int = Query(50, ge=1, le=200, description="每页条数"),
    status: str = Query(None, description="状态过滤"),
    tag: str = Query(None, description="标签过滤"),
    keyword: str = Query(None, description="关键词搜索"),
    db: Session = Depends(get_db_session),
):
    """查询处理记录列表"""
    records = ImageCRUD.get_all(db, skip=skip, limit=limit,
                                 status=status, tag=tag, keyword=keyword)
    total = ImageCRUD.count(db, status=status, tag=tag, keyword=keyword)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "records": [r.to_dict() for r in records],
    }


@router.get("/api/records/{record_id}")
async def get_record(record_id: int, db: Session = Depends(get_db_session)):
    """查询单条记录详情"""
    record = ImageCRUD.get_by_id(db, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    return record.to_dict()


@router.delete("/api/records/{record_id}")
async def delete_record(record_id: int, db: Session = Depends(get_db_session)):
    """删除记录（不删除文件）"""
    record = ImageCRUD.get_by_id(db, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    db.delete(record)
    db.commit()
    return {"message": "删除成功", "id": record_id}


# ----- 备注与标签管理 -----

@router.put("/api/records/{record_id}/note")
async def update_note(
    record_id: int,
    note: str = Form(..., description="备注内容"),
    db: Session = Depends(get_db_session),
):
    """更新单张备注"""
    record = ImageCRUD.batch_update_note(db, record_id, note)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    return record.to_dict()


@router.put("/api/records/batch/tags")
async def batch_update_tags(
    record_ids: str = Form(..., description="记录ID列表（逗号分隔）"),
    tags: str = Form(..., description="新增标签（JSON数组或逗号分隔）"),
    db: Session = Depends(get_db_session),
):
    """批量追加标签"""
    try:
        ids = [int(x.strip()) for x in record_ids.split(",") if x.strip()]
    except ValueError:
        raise HTTPException(status_code=400, detail="record_ids 格式错误")

    tag_list = parse_tags(tags)
    if not tag_list:
        raise HTTPException(status_code=400, detail="标签不能为空")

    count = ImageCRUD.batch_update_tags(db, ids, tag_list)
    return {"message": f"已更新 {count} 条记录的标签", "tags": tag_list}


# ----- 文件下载 -----

@router.get("/api/download/{record_id}")
async def download_output(record_id: int, db: Session = Depends(get_db_session)):
    """下载处理后的图片"""
    record = ImageCRUD.get_by_id(db, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    if not record.output_path or not Path(record.output_path).exists():
        raise HTTPException(status_code=404, detail="输出文件不存在")
    return FileResponse(
        path=record.output_path,
        filename=record.output_name or "output.png",
        media_type="image/png",
    )


@router.get("/api/download/{record_id}/original")
async def download_original(record_id: int, db: Session = Depends(get_db_session)):
    """下载原始图片"""
    record = ImageCRUD.get_by_id(db, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    # 先查输出目录，再查上传目录
    for path in [record.output_path, record.original_path]:
        if path and Path(path).exists():
            return FileResponse(
                path=path,
                filename=record.original_name,
            )
    raise HTTPException(status_code=404, detail="文件不存在")


# ----- 文件夹监控管理 -----

@router.get("/api/watcher/status")
async def watcher_status():
    """获取监控器状态"""
    from .watcher import get_watcher
    watcher = get_watcher()
    return {
        "running": watcher.is_running,
        "watch_dir": watcher.watch_dir or "未配置",
    }


@router.post("/api/watcher/start")
async def watcher_start():
    """启动文件夹监控"""
    from .watcher import get_watcher
    watcher = get_watcher(process_callback=_watcher_callback)
    success = watcher.start()
    if success:
        return {"message": "监控已启动", "watch_dir": watcher.watch_dir}
    else:
        raise HTTPException(status_code=500, detail="启动监控失败，请检查配置")


@router.post("/api/watcher/stop")
async def watcher_stop():
    """停止文件夹监控"""
    from .watcher import get_watcher
    watcher = get_watcher()
    watcher.stop()
    return {"message": "监控已停止"}


# ----- 系统配置 -----

@router.get("/api/config")
async def get_config():
    """获取当前配置信息"""
    return {
        "model_type": config.MODEL_TYPE,
        "max_image_size": config.MAX_IMAGE_SIZE,
        "allowed_extensions": list(config.ALLOWED_EXTENSIONS),
        "max_upload_size_mb": config.MAX_UPLOAD_SIZE // 1024 // 1024,
        "default_name_template": config.DEFAULT_NAME_TEMPLATE,
        "default_prefix": config.DEFAULT_PREFIX,
        "watch_dir": config.WATCH_DIR or "未启用",
        "max_workers": config.MAX_WORKERS,
        "batch_size": config.BATCH_SIZE,
    }
