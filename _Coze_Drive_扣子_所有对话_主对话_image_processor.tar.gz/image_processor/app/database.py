"""
图片批量抠图处理系统 - 数据库模型与操作
使用 SQLite + SQLAlchemy 管理处理记录
"""
import json
import logging
from datetime import datetime
from typing import Optional, List

from sqlalchemy import (
    create_engine, Column, Integer, String, Text, DateTime,
    Enum as SAEnum, Float, event
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session

from . import config

logger = logging.getLogger(__name__)

# ============================================================
# 数据库引擎与会话
# ============================================================
engine = create_engine(
    f"sqlite:///{config.DB_PATH}",
    connect_args={"check_same_thread": False},
    pool_pre_ping=True,
    echo=False,
)

# SQLite 优化：启用 WAL 模式提升并发性能
@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.close()

SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()


# ============================================================
# 数据模型
# ============================================================
class ImageRecord(Base):
    """图片处理记录表"""
    __tablename__ = "image_records"

    id = Column(Integer, primary_key=True, autoincrement=True, comment="主键ID")
    original_name = Column(String(500), nullable=False, comment="原始文件名")
    original_path = Column(String(1000), nullable=True, comment="原始文件路径")
    output_name = Column(String(500), nullable=True, comment="输出文件名")
    output_path = Column(String(1000), nullable=True, comment="输出文件路径")

    # 备注与标签
    note = Column(Text, default="", comment="单张备注")
    tags = Column(Text, default="[]", comment="标签列表（JSON数组）")

    # 处理状态: pending / processing / success / failed
    status = Column(String(20), default="pending", comment="处理状态")
    error_message = Column(Text, nullable=True, comment="错误信息")

    # 文件信息
    file_size = Column(Float, default=0, comment="文件大小（KB）")
    width = Column(Integer, nullable=True, comment="图片宽度")
    height = Column(Integer, nullable=True, comment="图片高度")

    # 时间戳
    upload_time = Column(DateTime, default=datetime.utcnow, comment="上传时间")
    process_start_time = Column(DateTime, nullable=True, comment="开始处理时间")
    process_end_time = Column(DateTime, nullable=True, comment="处理完成时间")
    created_at = Column(DateTime, default=datetime.utcnow, comment="记录创建时间")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")

    # 处理参数
    model_type = Column(String(50), default=config.MODEL_TYPE, comment="使用的模型类型")
    batch_id = Column(String(100), nullable=True, comment="批次ID")
    naming_template = Column(String(500), nullable=True, comment="命名模板")

    def to_dict(self):
        """转换为字典"""
        tags = self.tags
        if isinstance(tags, str):
            try:
                tags = json.loads(tags)
            except (json.JSONDecodeError, TypeError):
                tags = []
        return {
            "id": self.id,
            "original_name": self.original_name,
            "original_path": self.original_path,
            "output_name": self.output_name,
            "output_path": self.output_path,
            "note": self.note or "",
            "tags": tags if isinstance(tags, list) else [],
            "status": self.status,
            "error_message": self.error_message,
            "file_size": round(self.file_size or 0, 2),
            "width": self.width,
            "height": self.height,
            "upload_time": self.upload_time.isoformat() if self.upload_time else None,
            "process_start_time": self.process_start_time.isoformat() if self.process_start_time else None,
            "process_end_time": self.process_end_time.isoformat() if self.process_end_time else None,
            "model_type": self.model_type,
            "batch_id": self.batch_id,
            "naming_template": self.naming_template,
        }


# ============================================================
# 数据库初始化
# ============================================================
def init_db():
    """创建所有表"""
    Base.metadata.create_all(bind=engine)
    logger.info(f"数据库初始化完成: {config.DB_PATH}")


def get_db() -> Session:
    """获取数据库会话（依赖注入用）"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ============================================================
# CRUD 操作
# ============================================================
class ImageCRUD:
    """图片记录增删改查"""

    @staticmethod
    def create(db: Session, **kwargs) -> ImageRecord:
        """创建记录"""
        record = ImageRecord(**kwargs)
        db.add(record)
        db.commit()
        db.refresh(record)
        return record

    @staticmethod
    def get_by_id(db: Session, record_id: int) -> Optional[ImageRecord]:
        """按ID查询"""
        return db.query(ImageRecord).filter(ImageRecord.id == record_id).first()

    @staticmethod
    def get_all(db: Session, skip: int = 0, limit: int = 50,
                status: str = None, tag: str = None,
                keyword: str = None) -> List[ImageRecord]:
        """分页查询，支持按状态/标签/关键词过滤"""
        query = db.query(ImageRecord)
        if status:
            query = query.filter(ImageRecord.status == status)
        if tag:
            # 标签模糊匹配（JSON数组中查找）
            query = query.filter(ImageRecord.tags.contains(tag))
        if keyword:
            query = query.filter(
                ImageRecord.original_name.contains(keyword) |
                ImageRecord.note.contains(keyword)
            )
        return query.order_by(ImageRecord.id.desc()).offset(skip).limit(limit).all()

    @staticmethod
    def count(db: Session, status: str = None, tag: str = None,
              keyword: str = None) -> int:
        """统计总数"""
        query = db.query(ImageRecord)
        if status:
            query = query.filter(ImageRecord.status == status)
        if tag:
            query = query.filter(ImageRecord.tags.contains(tag))
        if keyword:
            query = query.filter(
                ImageRecord.original_name.contains(keyword) |
                ImageRecord.note.contains(keyword)
            )
        return query.count()

    @staticmethod
    def update(db: Session, record_id: int, **kwargs) -> Optional[ImageRecord]:
        """更新记录"""
        record = db.query(ImageRecord).filter(ImageRecord.id == record_id).first()
        if not record:
            return None
        for key, value in kwargs.items():
            if hasattr(record, key):
                setattr(record, key, value)
        record.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(record)
        return record

    @staticmethod
    def batch_update_tags(db: Session, record_ids: List[int], tags: List[str]) -> int:
        """批量更新标签（追加模式）"""
        count = 0
        for rid in record_ids:
            record = db.query(ImageRecord).filter(ImageRecord.id == rid).first()
            if record:
                existing = json.loads(record.tags) if record.tags else []
                merged = list(set(existing + tags))
                record.tags = json.dumps(merged, ensure_ascii=False)
                record.updated_at = datetime.utcnow()
                count += 1
        db.commit()
        return count

    @staticmethod
    def batch_update_note(db: Session, record_id: int, note: str) -> Optional[ImageRecord]:
        """更新单张备注"""
        return ImageCRUD.update(db, record_id, note=note)

    @staticmethod
    def get_stats(db: Session) -> dict:
        """获取统计信息"""
        total = db.query(ImageRecord).count()
        success = db.query(ImageRecord).filter(ImageRecord.status == "success").count()
        failed = db.query(ImageRecord).filter(ImageRecord.status == "failed").count()
        pending = db.query(ImageRecord).filter(ImageRecord.status == "pending").count()
        processing = db.query(ImageRecord).filter(ImageRecord.status == "processing").count()
        return {
            "total": total,
            "success": success,
            "failed": failed,
            "pending": pending,
            "processing": processing,
        }
