"""
图片批量抠图处理系统 - 抠图处理模块
支持 BiRefNet 和 RMBG-2.0 两种模型
"""
import io
import logging
import time
from pathlib import Path
from typing import Optional, Tuple
from PIL import Image

import numpy as np
import torch
from transformers import AutoModelForImageSegmentation, AutoProcessor

from . import config

logger = logging.getLogger(__name__)


class BackgroundRemover:
    """
    背景移除处理器
    支持模型: BiRefNet / RMBG-2.0
    自动检测 GPU/CPU，支持单张与批量处理
    """

    def __init__(self, model_type: str = None):
        self.model_type = model_type or config.MODEL_TYPE
        self.model = None
        self.processor = None
        self.device = None
        self._loaded = False

    def load_model(self):
        """加载模型到内存"""
        if self._loaded:
            logger.info("模型已加载，跳过")
            return

        logger.info(f"正在加载模型: {self.model_type}")
        start_time = time.time()

        # 检测设备
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"使用设备: {self.device}")

        # 根据模型类型加载
        if self.model_type == "birefnet":
            model_name = config.BIREFNET_MODEL
        elif self.model_type == "rmbg2":
            model_name = config.RMBG2_MODEL
        else:
            raise ValueError(f"不支持的模型类型: {self.model_type}")

        try:
            # 确定数据类型
            dtype = torch.float16 if self.device.type == "cuda" else torch.float32

            logger.info(f"加载模型: {model_name} (dtype={dtype})")
            self.model = AutoModelForImageSegmentation.from_pretrained(
                model_name,
                trust_remote_code=True,
                torch_dtype=dtype,
                cache_dir=config.MODEL_CACHE_DIR,
            )
            self.model = self.model.to(self.device)
            self.model.eval()

            # 加载预处理器
            self.processor = AutoProcessor.from_pretrained(
                model_name,
                trust_remote_code=True,
                cache_dir=config.MODEL_CACHE_DIR,
            )

            self._loaded = True
            elapsed = time.time() - start_time
            logger.info(f"模型加载完成，耗时: {elapsed:.1f}s")

        except Exception as e:
            logger.error(f"模型加载失败: {e}")
            raise

    def remove_background(self, image: Image.Image) -> Image.Image:
        """
        对单张图片执行抠图
        :param image: PIL Image 对象
        :return: 去除背景后的 PIL Image（RGBA，透明背景）
        """
        if not self._loaded:
            self.load_model()

        original_size = image.size  # (width, height)

        # 预处理：转换为 RGB（确保格式一致）
        if image.mode != "RGB":
            image = image.convert("RGB")

        # 使用 processor 处理输入
        inputs = self.processor(images=image, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}

        # 推理（无梯度计算）
        with torch.no_grad():
            outputs = self.model(**inputs)

        # ---- 后处理：提取蒙版 ----
        # 模型输出可能是多种格式，统一处理
        # 优先尝试 logits 属性，其次尝试最后一个输出
        if hasattr(outputs, 'logits'):
            logits = outputs.logits
        elif isinstance(outputs, (tuple, list)):
            logits = outputs[-1]
        else:
            logits = outputs

        # 如果 logits 是 dict（某些模型），取第一个 tensor 值
        if isinstance(logits, dict):
            logits = list(logits.values())[0]

        # 确保是 4D tensor: [B, C, H, W]
        if logits.dim() == 2:
            logits = logits.unsqueeze(0).unsqueeze(0)
        elif logits.dim() == 3:
            logits = logits.unsqueeze(0)

        # 取第一个 batch / 第一个通道
        mask_tensor = logits[0, 0] if logits.shape[1] == 1 else logits[0].mean(dim=0)

        # Sigmoid 归一化到 [0, 1]
        mask_tensor = torch.sigmoid(mask_tensor)

        # Resize 到原图尺寸
        mask_np = mask_tensor.cpu().numpy()
        mask_image = Image.fromarray((mask_np * 255).astype(np.uint8), mode="L")
        mask_image = mask_image.resize(original_size, Image.LANCZOS)

        # 确保蒙版尺寸与原图一致
        if mask_image.size != original_size:
            mask_image = mask_image.resize(original_size, Image.LANCZOS)

        # 将蒙版应用到原图（生成透明背景）
        result = image.convert("RGBA")
        result.putalpha(mask_image)

        return result

    def process_file(self, input_path: str, output_path: str) -> dict:
        """
        处理单个文件
        :param input_path: 输入文件路径
        :param output_path: 输出文件路径
        :return: 处理结果字典
        """
        start_time = time.time()
        result = {
            "input_path": input_path,
            "output_path": output_path,
            "success": False,
            "error": None,
            "elapsed": 0,
            "width": None,
            "height": None,
        }

        try:
            # 打开图片
            image = Image.open(input_path)
            result["width"] = image.width
            result["height"] = image.height

            # 检查尺寸，必要时缩放
            max_side = max(image.size)
            if max_side > config.MAX_IMAGE_SIZE:
                scale = config.MAX_IMAGE_SIZE / max_side
                new_size = (int(image.width * scale), int(image.height * scale))
                image = image.resize(new_size, Image.LANCZOS)
                logger.info(f"图片已缩放: {result['width']}x{result['height']} -> {new_size}")

            # 执行抠图
            output_image = self.remove_background(image)

            # 保存结果（PNG 格式保留透明通道）
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            output_image.save(output_path, format="PNG", optimize=True)

            result["success"] = True
            result["elapsed"] = round(time.time() - start_time, 2)
            logger.info(f"处理完成: {input_path} -> {output_path} ({result['elapsed']}s)")

        except Exception as e:
            result["error"] = str(e)
            result["elapsed"] = round(time.time() - start_time, 2)
            logger.error(f"处理失败: {input_path} - {e}")

        return result

    def process_batch(self, file_pairs: list) -> list:
        """
        批量处理文件
        :param file_pairs: [(input_path, output_path), ...]
        :return: 处理结果列表
        """
        results = []
        total = len(file_pairs)
        logger.info(f"开始批量处理，共 {total} 张图片")

        for i, (input_path, output_path) in enumerate(file_pairs, 1):
            logger.info(f"处理进度: [{i}/{total}] {input_path}")
            result = self.process_file(input_path, output_path)
            results.append(result)

        success_count = sum(1 for r in results if r["success"])
        logger.info(f"批量处理完成: {success_count}/{total} 成功")

        return results


# ============================================================
# 全局单例
# ============================================================
_processor_instance: Optional[BackgroundRemover] = None


def get_processor(model_type: str = None) -> BackgroundRemover:
    """获取全局抠图处理器实例"""
    global _processor_instance
    if _processor_instance is None:
        _processor_instance = BackgroundRemover(model_type)
    return _processor_instance
