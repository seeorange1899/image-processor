"""
图片批量抠图处理系统 - 文件夹监控模块
使用 watchdog 监控指定目录，自动处理新增图片
"""
import logging
import time
import threading
from pathlib import Path
from typing import Optional, Callable

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileCreatedEvent

from . import config

logger = logging.getLogger(__name__)


class ImageHandler(FileSystemEventHandler):
    """
    文件系统事件处理器
    监控新图片文件创建事件，触发自动处理
    """

    def __init__(self, process_callback: Callable, settle_time: float = 2.0):
        super().__init__()
        self.process_callback = process_callback
        self.settle_time = settle_time  # 等待文件写入完成的时间
        self._processing = set()  # 正在处理的文件路径集合，避免重复
        self._lock = threading.Lock()

    def on_created(self, event):
        """文件创建事件"""
        if event.is_directory:
            return

        file_path = Path(event.src_path)

        # 检查文件扩展名是否为支持的图片格式
        if file_path.suffix.lower() not in config.ALLOWED_EXTENSIONS:
            return

        # 避免重复处理
        with self._lock:
            if str(file_path) in self._processing:
                return
            self._processing.add(str(file_path))

        # 启动延迟处理线程（等待文件写入完成）
        thread = threading.Thread(
            target=self._delayed_process,
            args=(str(file_path),),
            daemon=True,
        )
        thread.start()

    def _delayed_process(self, file_path: str):
        """延迟处理：等待文件写入完成后执行"""
        try:
            # 等待文件写入完成
            time.sleep(self.settle_time)

            # 确认文件仍然存在
            if not Path(file_path).exists():
                logger.warning(f"文件已不存在: {file_path}")
                return

            # 检查文件大小是否稳定（确保写入完成）
            size1 = Path(file_path).stat().st_size
            time.sleep(0.5)
            size2 = Path(file_path).stat().st_size
            if size1 != size2:
                logger.info(f"文件仍在写入中，继续等待: {file_path}")
                time.sleep(self.settle_time)

            logger.info(f"监控到新图片: {file_path}")
            self.process_callback(file_path)

        except Exception as e:
            logger.error(f"监控处理异常: {file_path} - {e}")

        finally:
            with self._lock:
                self._processing.discard(file_path)


class DirectoryWatcher:
    """
    文件夹监控器
    支持启动/停止监控，自动处理新增图片
    """

    def __init__(self, watch_dir: str = None, process_callback: Callable = None):
        self.watch_dir = watch_dir or config.WATCH_DIR
        self.observer: Optional[Observer] = None
        self._running = False

        # 回调函数
        self.process_callback = process_callback

        # 事件处理器
        self.handler = ImageHandler(
            process_callback=self._on_new_image,
            settle_time=config.WATCH_SETTLE_TIME,
        )

    def _on_new_image(self, file_path: str):
        """新图片检测到后的回调"""
        if self.process_callback:
            try:
                self.process_callback(file_path)
            except Exception as e:
                logger.error(f"处理回调异常: {file_path} - {e}")
        else:
            logger.warning(f"未配置处理回调，跳过: {file_path}")

    def start(self):
        """启动监控"""
        if not self.watch_dir:
            logger.warning("未配置监控目录，跳过启动")
            return False

        watch_path = Path(self.watch_dir)
        if not watch_path.exists():
            watch_path.mkdir(parents=True, exist_ok=True)
            logger.info(f"创建监控目录: {self.watch_dir}")

        if self._running:
            logger.warning("监控器已在运行中")
            return True

        try:
            self.observer = Observer()
            self.observer.schedule(
                self.handler,
                self.watch_dir,
                recursive=config.WATCH_RECURSIVE,
            )
            self.observer.start()
            self._running = True
            logger.info(f"文件夹监控已启动: {self.watch_dir}")
            return True

        except Exception as e:
            logger.error(f"启动文件夹监控失败: {e}")
            return False

    def stop(self):
        """停止监控"""
        if self.observer and self._running:
            self.observer.stop()
            self.observer.join(timeout=5)
            self._running = False
            logger.info("文件夹监控已停止")

    @property
    def is_running(self) -> bool:
        return self._running


# ============================================================
# 全局监控器实例
# ============================================================
_watcher_instance: Optional[DirectoryWatcher] = None


def get_watcher(process_callback: Callable = None) -> DirectoryWatcher:
    """获取全局监控器实例"""
    global _watcher_instance
    if _watcher_instance is None:
        _watcher_instance = DirectoryWatcher(process_callback=process_callback)
    return _watcher_instance
