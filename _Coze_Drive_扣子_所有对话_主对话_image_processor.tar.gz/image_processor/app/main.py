"""
图片批量抠图处理系统 - FastAPI 主应用入口
"""
import logging
import sys
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

from . import config
from .database import init_db
from .api import router as api_router
from .watcher import get_watcher
from .api import _watcher_callback

# ============================================================
# 日志配置
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(config.LOG_DIR / "app.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)


# ============================================================
# 应用生命周期
# ============================================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用启动/关闭事件"""
    # 启动时
    logger.info("=" * 60)
    logger.info("图片批量抠图处理系统 启动中...")
    logger.info(f"  模型类型: {config.MODEL_TYPE}")
    logger.info(f"  数据目录: {config.DATA_DIR}")
    logger.info(f"  监控目录: {config.WATCH_DIR or '未启用'}")
    logger.info("=" * 60)

    # 初始化数据库
    init_db()

    # 启动文件夹监控（如果配置了监控目录）
    if config.WATCH_DIR:
        watcher = get_watcher(process_callback=_watcher_callback)
        watcher.start()

    yield

    # 关闭时
    logger.info("系统关闭中...")
    if config.WATCH_DIR:
        watcher = get_watcher()
        watcher.stop()
    logger.info("系统已关闭")


# ============================================================
# 创建 FastAPI 应用
# ============================================================
app = FastAPI(
    title="图片批量抠图处理系统",
    description="基于 BiRefNet/RMBG-2.0 的智能抠图系统，支持批量上传、文件夹监控、标签管理",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册 API 路由
app.include_router(api_router, tags=["API"])

# 静态文件服务
static_dir = config.BASE_DIR / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

# 数据文件服务（输出图片预览）
if config.OUTPUT_DIR.exists():
    app.mount("/outputs", StaticFiles(directory=str(config.OUTPUT_DIR)), name="outputs")


# ============================================================
# 根路由 - 前端页面
# ============================================================
@app.get("/")
async def index():
    """返回前端主页"""
    index_path = config.BASE_DIR / "static" / "index.html"
    if index_path.exists():
        return FileResponse(str(index_path))
    return {"message": "图片批量抠图处理系统 API 已启动", "docs": "/docs"}


# ============================================================
# 启动入口
# ============================================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=config.HOST,
        port=config.PORT,
        reload=config.DEBUG,
    )
